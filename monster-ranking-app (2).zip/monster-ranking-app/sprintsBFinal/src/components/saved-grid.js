import React from "react";
import "../css/saved-grid.css";
import useAllMonsters from "../hooks/use-all-monsters";
import Monster from "./monster-save";
import Loading from "./loading-spinner";

function SavedGrid(props) {
	const userId = props.user.uid;
	const [monster, isLoading, errorMessage] = useAllMonsters(userId);

	console.log(userId);

	return (
		<div className="monster-container">
			{isLoading && <Loading />}

			{errorMessage && "this is error"}
			<ul className="monster-list">
				{monster.map((monsterDoc) => {
					const id = monsterDoc.id;
					const data = monsterDoc.data();

					return (
						<li key={id}>
							<Monster userId={userId} id={id} data={data} />
						</li>
					);
				})}
			</ul>
		</div>
	);
}

export default SavedGrid;
