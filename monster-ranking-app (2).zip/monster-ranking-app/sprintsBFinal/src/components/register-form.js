import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../css/register-form.css";
import { users } from "../data/firebase";

function RegisterForm(props) {
	const { user } = props;

	const [isSaving, setIsSaving] = useState(false);

	const [name, setName] = useState();
	const [favMonster, setFavMonster] = useState();

	const onNameChange = (event) => {
		setName(event.target.value);
	};

	const onFavMonster = (event) => {
		setFavMonster(event.target.value);
	};

	const save = async (event) => {
		event.preventDefault();
		setIsSaving(true);
		try {
			await users.doc(user.uid).set({
				name,
				favMonster,
			});
		} catch (error) {
			console.error(error);
		}
		setIsSaving(false);
	};

	return (
		<>
			<form onSubmit={save} className="register-form">
				<div className="register-form__div">
					<label className="register-form__label">Name:</label>
					<input
						className="register-form__input"
						id="name"
						value={name}
						onChange={onNameChange}
						type="text"
					></input>
				</div>
				<div className="register-form__div">
					<label className="register-form__label">Favorite Monster:</label>
					<input
						className="register-form__input"
						id="favMonster"
						value={favMonster}
						onChange={onFavMonsterChange}
						type="text"
					></input>
				</div>
				<div className="register-form__button-container">
					<button className="register-form__button">
						{isSaving ? "Saving" : "Save"}
					</button>
				</div>
				<div className="register-form__link-container">
					<Link className=".register-form__link" to="/home">
						Next
					</Link>
				</div>
			</form>
		</>
	);
}

export default RegisterForm;