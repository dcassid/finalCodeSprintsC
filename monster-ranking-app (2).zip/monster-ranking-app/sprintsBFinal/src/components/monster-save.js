import React, { useState } from "react";
import { Delete } from "@material-ui/icons";
import { monsters, users } from "../data/firebase";
import ErrorMessage from "./error-message";
import "../css/monsters-save.css";

function monster(props) {
	const { id, data, userId } = props;
	const [isDeleting, setIsDeleting] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");
	const {
		name,
		place,
		rating,
	} = data;
	const deleteMonster = async () => {
		setIsDeleting(true);
		setErrorMessage("");
		try {
			const docRef = users.doc(userId).collection("monsters").doc(id);
			await docRef.delete();
		} catch (error) {
			console.error(error);
			setErrorMessage("Something is hinky! We're trying to fix it.");
			setIsDeleting(false);
		}
	};

	return (
		<div className="contents">
			<button
				className="delete__button"
				disabled={isDeleting}
				onClick={deleteMonster}
			>
				<Delete />
			</button>

			<img className="save__image" src={image} />

			<h3 className="save__name">{name}
            </h3>
			<h3 className="save__place">{place}
             </h3>
			<h3 className="save__rating">{rating}</h3>
			{errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
		</div>
	);
}
export default Monster;