import React, { useState, useEffect } from "react";
import "../css/settings-form.css";
import { provider, auth, users } from "../data/firebase";

function SettingsForm(props) {
	const { user } = props;

	const [isSaving, setIsSaving] = useState(false);

	const [name, setName] = useState();
    const [favMonster, setFavMonster] = useState();

	const onNameChange = (event) => {
		setName(event.target.value);
	};

	const onFavMonsterChange = (event) => {
		setFavMonster(event.target.value);
	};

	const update = async (event) => {
		event.preventDefault();
		setIsSaving(true);
		try {
			await users.doc(user.uid).set({
                name,
                favMonster,
			});
		} catch (error) {
			console.error(error);
		}
		setIsSaving(false);
	};

	useEffect(() => {
		async function read() {
			try {
				const snapshot = await users.doc(user.uid).get();

				const data = snapshot.data();
				setFavMonster(data.favMonster);
				setName(data.name);
			} catch (error) {
				console.error(error);
			}
		}
		read();
	}, [user]);

	const read = async () => {
		try {
			await users.doc(user).get({
				name,
				favMonster,
			});
		} catch (error) {
			console.error(error);
		}
	};

	return (
		<>
			<form onSubmit={update} className="settings-form">
				<div className="settings-form__div">
					<label className="settings-form__label">Name:</label>
					<input
						className="settings-form__input"
						id="userName"
						value={name}
						onChange={onNameChange}
						type="text"
					></input>
				</div>
				<div className="settings-form__div">
					<label className="settings-form__label">Favorite Monster:</label>
					<input
						className="settings-form__input"
						id="favMonster"
						value={favMonster}
						onChange={onFavMonsterChange}
						type="text"
					></input>
				</div>
				<div className="settings-form__button_container">
					<button className="settings-form__button">
						{isSaving ? "Saving" : "Save"}
					</button>
				</div>
			</form>
		</>
	);
}

export default SettingsForm;