import React from "react";
import { Link } from "react-router-dom";
import "./nav.css";

function Nav() {
  return (
    <nav className="nav">
      <Link className="nav__link" to="/">
        All Monsters
      </Link>
      <Link className="nav__link" to="/add">
        Add Monster
      </Link>
      <Link className="nav__link" to="/saved">
        Saved Monsters
      </Link>
      <Link className="nav__link" to="/user-settings">
        User Settings
      </Link>
    </nav>
  );
}

export default Nav;
