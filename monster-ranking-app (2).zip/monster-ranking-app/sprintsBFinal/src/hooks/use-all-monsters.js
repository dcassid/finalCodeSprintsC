import { useState, useEffect } from "react";
import { monsters, users } from "../data/firebase";

function useAllMonsters(userId) {
	const [monsters, setMonsters] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");
	useEffect(() => {
		setIsLoading(true);
		const onNext = (snapshot) => {
			setIsLoading(false);
			const docs = snapshot.docs;
			setMonsters(docs);
		};
		const onError = (error) => {
			setIsLoading(false);
			setErrorMessage("There was a problem loading. Please try again.");
			console.error(error);
		};

		const unsubscribe = users
			.doc(userId)
			.collection("monsters")
			.orderBy("time", "desc")
			.onSnapshot(onNext, onError);

		return unsubscribe;
	}, []);

	return [monsters, isLoading, errorMessage];
}

export default useAllMonsters;
