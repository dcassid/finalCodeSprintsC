import { useState } from "react";
import { monsters, users } from "../data/firebase";
import firebase from "firebase/app";
import faker from "faker";

function useSaveMonsters(userId) {
	const [isSaving, setIsSaving] = useState(false);
	const [hasSaved, setHasSaved] = useState(false);

	const [monstersData, setMonstersData] = useState(() => {
		return {
			name: faker.name.findName(),
			place: faker.address.stateAbbr(),
			rating: faker.number.monsterRating(),
		};
	});

	const randomData = () => {
		setHasSaved(false);
		setMonstersData({
			name: faker.name.findName(),
			place: faker.address.stateAbbr(),
			rating: faker.number.monsterRating(),
		});
	};

	const {
			name,
			place,
			rating,
	} = monstersData;

	function getAge(min, max) {
		min = Math.ceil(min);
		max = Math.floor(max);
		return Math.floor(Math.random() * (max - min + 1) + min);
	}

	let classes = "SaveButton";
	if (hasSaved === true) classes += "-saved";

	const save = async (userId, event) => {
		setIsSaving(true);
		setHasSaved(false);
		console.log(userId);
		try {
			await users.doc(userId).collection("monsters").add({
				name,
			    place,
			    rating,
				time: firebase.firestore.Timestamp.now(),
			});
			setHasSaved(true);
		} catch (error) {
			console.error(error);
		}

		setIsSaving(false);
	};

	return [
	    name,
		place,
		rating,
	];
}

export default useSaveMonsters;
